from .music_plugin import MusicPlugin

def setup():
    return MusicPlugin()