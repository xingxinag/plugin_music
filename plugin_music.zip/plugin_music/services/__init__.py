from .qq_music import QQMusicService
from .netease_music import NeteaseMusicService
from .kugou_music import KugouMusicService